<script setup>
import PhoneNumCards from '@/components/PhoneNumCards.vue';
import FilterForm from '@/components/FilterForm.vue';
import { useMobileStore } from '@/stores/mobileStore';
const mobileStore=useMobileStore()
</script>

<template>
  <h1 class="m-3 text-center">Telefonszámok</h1>
    <div class="container d-flex justify-content-center">
      <FilterForm/>
    </div>
    <h3 v-if="mobileStore.filteredPhoneNumbers.length<1" class="text-center">Nincs ilyen adat!</h3>
      <div v-else  class="row gx-2 mt-3" >
          <PhoneNumCards v-for="p in mobileStore.filteredPhoneNumbers" :key="p.id" :phonenumbers="p"/>
        </div>
</template>
