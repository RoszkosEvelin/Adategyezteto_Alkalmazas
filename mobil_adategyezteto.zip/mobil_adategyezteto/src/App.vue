<script setup>
  import { onMounted } from 'vue';
  import axios from 'axios';
  import { useMobileStore } from './stores/mobileStore';

  const mobileStore = useMobileStore()

  onMounted(async()=>{
    let resp = await axios.get("http://localhost:3000/sim_cards")

    mobileStore.phoneNumbers = resp.data
    mobileStore.filteredPhoneNumbers = resp.data
  })

  
</script>

<template>
  <nav>
    <RouterLink to="/">Főoldal</RouterLink>
  </nav>
  <RouterView/>
</template>