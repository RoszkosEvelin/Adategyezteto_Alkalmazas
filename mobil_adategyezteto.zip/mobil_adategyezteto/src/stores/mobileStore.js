import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

export const useMobileStore = defineStore('mobile', () => {

  const phoneNumbers = ref([])
  const filteredPhoneNumbers = ref([])

  function filterByStatus(id,id2,id3){
    if(id){
      filteredPhoneNumbers.value=phoneNumbers.value.filter(s=>s.status==id)
    }
    if(id2){
      filteredPhoneNumbers.value=phoneNumbers.value.filter(s=>s.owner_name==id2)
    }
    if(id3){
      filteredPhoneNumbers.value=phoneNumbers.value.filter(s=>s.phone_number==id3)
    }
    if(id,id2){
      filteredPhoneNumbers.value=phoneNumbers.value.filter(s=>s.status==id && s.owner_name==id2)
    }
    if(id,id3){
       filteredPhoneNumbers.value=phoneNumbers.value.filter(s=>s.status==id && s.phone_number==id3)
    }
    if(id2,id3){
      filteredPhoneNumbers.value=phoneNumbers.value.filter(s=>s.owner_name==id2 && s.phone_number==id3)
    }
    if(id,id2,id3){
       filteredPhoneNumbers.value=phoneNumbers.value.filter(s=>s.status==id && s.owner_name==id2 && s.phone_number==id3)
    }
  }

  function reset(){
    filteredPhoneNumbers.value=phoneNumbers.value
  }

  function orderByDate(){

  }

  function update(id){
    const date = new Date(); 
    const current_date = `${date.getFullYear()}-${date.getMonth()}-${date.getDay()}`
    const expiryDate=`${date.getFullYear()+1}-${date.getMonth()}-${date.getDay()}`


    var number = filteredPhoneNumbers.value.find(f=>f.id==id)

    number.status="verified"
    number.last_validation_date=current_date
    number.expiry_date=expiryDate

  }


  

  return { phoneNumbers,filteredPhoneNumbers,filterByStatus,reset,orderByDate,update}
})
