<script setup>
  import { useMobileStore } from '@/stores/mobileStore';
  const store = useMobileStore()
  defineProps({phonenumbers : Object})


</script>

<template>
    <div :style="{borderColor: new Date(phonenumbers.expiry_date)<new Date() ? 'red' : 'green'}" class="card col-12 col-sm-6 col-md-4 col-lg-3 border-2">
      <div class="header text-center">
        <p class="pt-3">Telefonszám:<br><b>{{phonenumbers.phone_number }}</b></p>
        <p>Tulajdonos:<br> <b>{{phonenumbers.owner_name }}</b></p>
        <p>Okmányazonosító:<br> <b>{{phonenumbers.id_card_number }}</b></p>
        <p>Szolgáltató:<br> <b>{{phonenumbers.provider }}</b></p>
        <p>Legutóbb frissítve: <b>{{ phonenumbers.last_validation_date }}</b></p>
        <p>Lejárat dátuma:<br><b>{{phonenumbers.expiry_date }}</b></p>

        <p id="status" class="pb-3">Státusz<br>
          <b :style="{color: phonenumbers.status == 'verified' ? 'green' :
          phonenumbers.status == 'pending' ? 'orange' :
          phonenumbers.status == 'expired' ? 'red' :'black'}">{{phonenumbers.status }}
          </b>
          <br>
          <button class="btn btn-primary mt-2" @click="store.update(phonenumbers.id)">Egyeztetés</button>
        </p>

      </div>
    </div>
</template>


