<script setup>
import { useMobileStore } from '@/stores/mobileStore';
import axios from 'axios';
import { onMounted } from 'vue';
import { ref } from 'vue';
const store = useMobileStore()

const statuszok=ref([])
const statuskod=ref("verified")
const nevkod=ref()
const telefonszamkod=ref()
onMounted(async () => {
  const resp = await axios.get("http://localhost:3000/sim_cards")

  for (const s of resp.data) {
    if (!statuszok.value.includes(s.status)) {
      statuszok.value.push(s.status)
    }
  }
})

</script>

<template>
  <form class="border border-2 rounded p-5" @submit.prevent="store.filterByStatus(statuskod,nevkod,telefonszamkod)">
    <strong>Szűrés név szerint</strong>
    <input v-model="nevkod" class="m-2" type="text" placeholder="Szabó Balázs">
    <br>
    <strong>Szűrés telefonszám szerint</strong>
    <input v-model="telefonszamkod" class="ms-2 mb-2" type="text" placeholder="+36705550011">
    <br>
    <strong class="me-2">Szűrés státusz szerint</strong>
    <select v-model="statuskod" name="state" >
      <option v-for="s in statuszok" :key="s" :value="s">
        {{ s }}
      </option>
    </select><br>
    <div class="mt-3 d-flex justify-content-center">
      <button class="btn btn-info ms-2" type="submit">Szűrés</button>
      <button class="btn btn-warning ms-2" type="button" @click="store.reset()">Alaphelyzet</button>
    </div>
  </form>
</template>